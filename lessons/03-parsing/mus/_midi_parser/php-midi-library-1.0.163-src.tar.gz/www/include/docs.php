					<h2>Documentation</h2>
					
					<ul>
						<li><a href="/docs/api/">API Documentation</a></li>
						<li><a href="/docs/coverage/">Code Coverage</a></li>
						<li><a href="/docs/pdepend">PHP Depend</a></li>
					</ul>