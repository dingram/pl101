					<h2>Resources</h2>
					
					<ul>
						<li><a href="http://www.sonicspot.com/guide/midifiles.html">MIDI File Format - The Sonic Spot</a></li>
						<li><a href="http://www.midi.org/techspecs/midispec.php">Official Spec</a></li>
					</ul>