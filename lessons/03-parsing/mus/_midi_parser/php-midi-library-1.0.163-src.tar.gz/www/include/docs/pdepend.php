					<h2>Dependencies</h2>
					<p>
						The PHP Depend library appears to be a bit buggy, but
						graphs are fun to look at, right? For more information about 
						PHP Depend, visit their <a href="http://pdepend.org/">website</a>.
					</p>
					
					<object data="/media/pdepend.svg" type="image/svg+xml" width="390" height="250">
						<embed src="/media/pdepend.svg" type="image/svg+xml" width="390" height="250" />
					</object>

					<object data="/media/pyramid.svg" type="image/svg+xml" width="390" height="250">
						<embed src="/media/pdepend.svg" type="image/svg+xml" width="390" height="250" />
					</object>