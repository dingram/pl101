<?php

	namespace Midi\Tests;

	require_once 'PHPUnit/Framework.php';
	require_once 'PHPUnit/Extensions/OutputTestCase.php';
	require_once dirname(dirname(__FILE__)) . '/src/Midi/bootstrap.php';

?>